import adexpsnapshot
adexpsnapshot.main()
